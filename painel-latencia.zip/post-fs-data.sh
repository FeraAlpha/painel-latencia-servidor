#!/system/bin/sh
MODDIR="${0%/*}"
# ensure our scripts are executable
chmod 0755 "$MODDIR/service.sh"
chmod 0755 "$MODDIR/customize.sh"
exit 0
