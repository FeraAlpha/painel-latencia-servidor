#!/system/bin/sh
# Também não precisa nada aqui ainda