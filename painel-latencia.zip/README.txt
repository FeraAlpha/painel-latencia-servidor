Painel Latência - Módulo Magisk (v2)
===================================

Esta versão é compatível com o shell mksh (Termux em muitos dispositivos Samsung/Android)
e não usa 'read -p' (substituído por read_prompt/printf).

Instalação (recomendada):
1) Abra Magisk Manager -> Modules -> remova a versão anterior (se quiser).
2) Instale este ZIP pelo Magisk Manager -> Install from storage.
3) Reinicie o aparelho.
4) No Termux execute:
   su
   sh /data/adb/modules/latencia.panel/painel-latencia.sh

Testes rápidos (no Termux, como root):
1) Testar leitura simples:
   su -c 'printf "digite algo: "; read x; echo "vc digitou: $x"'
2) Executar painel:
   su; sh /data/adb/modules/latencia.panel/painel-latencia.sh
