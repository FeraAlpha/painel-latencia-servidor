# ============================================
#  🚀 PERFORMANCE CORE - LATÊNCIA 
#      Otimização Anti-Delay/Jitter
# ============================================

# Animação de loading
sleep_anim() {
    for i in 1 2 3; do
        ui_print "$1."
        sleep 0.3
        ui_print "$1.."
        sleep 0.3
        ui_print "$1..."
        sleep 0.3
    done
}

# Barra de progresso
progress_bar() {
    ui_print ""
    ui_print -n "   "
    for i in $(seq 1 30); do
        ui_print -n "█"
        sleep 0.06
    done
    ui_print ""
}

# Status do sistema
ui_print "🔍 Verificando compatibilidade..."
sleep 0.5
ui_print "✅ Sistema compatível detectado"
ui_print "📱 Dispositivo: Android $(getprop ro.build.version.release)"
ui_print "⚡ Arquitetura: $(getprop ro.product.cpu.abi)"
ui_print ""

sleep_anim "🔧 Inicializando Processo de Otimização"
sleep 0.2

ui_print "📦 Carregando Arquivos Essenciais..."
progress_bar

ui_print "📁 Instalando Core Binário e Cliente Termux..."
sleep 0.4

# Instalar o binário de controle 'painel' no diretório do módulo
ui_print "-> Copiando: /system/bin/painel"
install -D "$MODPATH/painel" "/data/adb/modules/$MODID/painel"
chmod 755 /data/adb/modules/$MODID/painel

sleep_anim "⚙ Aplicando Otimizações de Performance"
sleep 0.6

ui_print ""
ui_print "┌─────────────────────────────────────┐"
ui_print "│         ✅ INSTALAÇÃO CONCLUÍDA     │"
ui_print "└─────────────────────────────────────┘"
ui_print ""

# --- Instruções Chave para o Usuário ---

ui_print "🔰 **ATIVAÇÃO VIA TERMUX:**"
ui_print "┌─────────────────────────────────────┐"
ui_print "│   📱 APÓS REINICIAR:               │"
ui_print "│                                     │"
ui_print "│   1. Abra o TERMUX                 │"
ui_print "│   2. Digite o comando:             │"
ui_print "│                                     │"
ui_print "│      $ painel                      │"
ui_print "│                                     │"
ui_print "│   🎮 Para ativar otimizações       │"
ui_print "└─────────────────────────────────────┘"
ui_print ""

sleep 1.0

# --- Finalização e Promocional ---

ui_print "🌐 **SUPORTE OFICIAL:**"
ui_print "   📺 YouTube: @feraalpha"
ui_print "   💬 Comunidade: t.me/feraalpha"
ui_print ""

ui_print "🎬 Abrindo Canal Oficial..."
sleep 0.8

# Comando para abrir o YouTube
(
    sleep 2
    am start -a android.intent.action.VIEW -d "https://youtube.com/@feraalpha" >/dev/null 2>&1
) &

ui_print "┌─────────────────────────────────────┐"
ui_print "│         🚀 PERFORMANCE CORE         │"
ui_print "│        Domine a Performance!        │"
ui_print "└─────────────────────────────────────┘"
ui_print ""

ui_print "⚡ Obrigado por escolher Fera Alpha!"
ui_print "   Reinicie e use 'painel' no Termux!"
ui_print ""