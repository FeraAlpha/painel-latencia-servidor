#!/system/bin/sh
# ==========================================
# 🔥 Termux Performance v1.0 🔥
# ==========================================

ui_print " "
ui_print "███████╗███████╗██████╗  █████╗ "
ui_print "██╔════╝██╔════╝██╔══██╗██╔══██╗"
ui_print "█████╗  █████╗  ██████╔╝███████║"
ui_print "██╔══╝  ██╔══╝  ██╔══██╗██╔══██║"
ui_print "██║     ███████╗██║  ██║██║  ██║"
ui_print "╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝"
ui_print " "
ui_print "            🔥 Termux Performance v1.0 🔥"
ui_print " "

sleep 2.1

ui_print "┏━━━━━━━━━━━━━━━━🔧 SOBRE O MÓDULO 🔧━━━━━━━━━━━━━━━━┓"
ui_print " "
ui_print "   ⚡ Otimizações avançadas aplicadas automaticamente"
ui_print "   🌀 Suporte completo via Termux para comandos extras"
ui_print "   🔥 Redução agressiva do delay de toque (input boost)"
ui_print "   💨 Menos atraso de tela + resposta instantânea"
ui_print "   🚀 Ajustes internos para diminuir input lag no USB"
ui_print "   🎮 Melhor estabilidade e fluidez para jogos competitivos"
ui_print "   🎯 Tweaks especiais para Free Fire (FPS / sensibilidade)"
ui_print "   🔧 Rotinas internas que otimizam durante a instalação"
ui_print " "
ui_print "   🛠 Compatível com Android 12 • 13 • 14 • 15 16"
ui_print " "
ui_print "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
ui_print " "

sleep 2

# === Canal Fera Alpha ===
ui_print "▬▬▬▬▬▬▬▬▬▬ CANAL FERA ALPHA ▬▬▬▬▬▬▬▬▬▬"
ui_print " "
ui_print "   📺 Inscreva-se no canal!"
ui_print "   🎮 Mais módulos e otimizações"
ui_print "   ⚡ Tutoriais exclusivos"
ui_print "   🔔 Ative as notificações"
ui_print " "
ui_print "   🌐 Link: youtube.com/@feraalpha"
ui_print " "

sleep 2

# === Tentativa de abrir o canal ===
ui_print "🔗 Conectando ao canal Fera Alpha..."
sleep 2

if command -v am >/dev/null 2>&1; then
    ui_print "📱 Abrindo YouTube..."
    am start -a android.intent.action.VIEW -d "https://youtube.com/@feraalpha?si=moXJBVAWOVhKS8yp" >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        ui_print "✅ YouTube aberto com sucesso!"
    else
        ui_print "❌ Não foi possível abrir o YouTube"
        ui_print "   Acesse manualmente: youtube.com/@feraalpha"
    fi
else
    ui_print "📢 Acesse manualmente após a instalação:"
    ui_print "   🌐 youtube.com/@feraalpha"
fi

ui_print " "
ui_print "🎉 Spoof Realme 15 Pro instalado com sucesso!"
ui_print "🔄 Reinicie seu dispositivo para aplicar as mudanças"
ui_print " "
ui_print "👉 Não esqueça de se inscrever no canal! 📺"

sleep 2
return 0