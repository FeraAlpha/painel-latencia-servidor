#!/system/bin/sh
MODDIR=${0%/*}

# Nada por enquanto