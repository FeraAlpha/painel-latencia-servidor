#!/system/bin/sh
MODDIR=${0%/*}

# Nada necessário aqui por enquanto