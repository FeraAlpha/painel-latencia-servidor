#!/system/bin/sh
MODPATH=${0%/*}

# ===================================================================
# 📌 FERA ALPHA - BOOT + TERMUX + ABRIR CANAL (CORRIGIDO vFINAL)
# ===================================================================

# Garantir permissões
chmod 755 $MODPATH/service.sh
chmod 755 $MODPATH/painel-latencia.sh 2>/dev/null

# Auto boot e ativação do painel
if [ -f "$MODPATH/enable_on_boot" ]; then
    sh "$MODPATH/painel-latencia.sh" --ativar-todos >/dev/null 2>&1 &
fi

# Aguarda Android iniciar totalmente
sleep 12

# Abrir canal no YouTube (link atualizado)
if command -v am >/dev/null 2>&1; then
    am start -a android.intent.action.VIEW \
        -d "https://youtube.com/@feraalpha?si=fcdvzG8ASNIqBLcB" >/dev/null 2>&1 &
fi