{
  "version": "1.0",
  "zipUrl": "https://raw.githubusercontent.com/SEU_USER/SEU_REPO/main/painel-latencia.zip",
  "changelog": "Primeira versão."
}